package com.example.wifidetect;

public class WifiListItems {
		 
		 String room;
		 String wname;
		 int strength;
		 
		 public String getroom() {
		  return room;
		 }
		 
		 public void setroom(String room) {
		  this.room = room;
		 }
		 
		 public String getwname() {
		  return wname;
		 }
		 
		 public void setwname(String wname) {
		  this.wname = wname;
		 }
		 
		 public int getstrength() {
		  return strength;
		 }
		 
		 public void setstrength(int strength) {
		  this.strength = strength;
		 }
		 

}